public class Main {
	public static void main(String[] args) {
		System.out.println("Yo what's up human! Oh you think you're fancy");
	}
}